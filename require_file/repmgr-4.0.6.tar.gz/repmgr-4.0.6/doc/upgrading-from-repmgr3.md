Upgrading from repmgr 3
=======================

This document has been integrated into the main `repmgr` documentation
and is now located here:

> [Upgrading from repmgr 3.x](https://repmgr.org/docs/4.0/upgrading-from-repmgr-3.html)


