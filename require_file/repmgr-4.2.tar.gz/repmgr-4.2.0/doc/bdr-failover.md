BDR failover with repmgrd
=========================

This document has been integrated into the main `repmgr` documentation
and is now located here:

> [BDR failover with repmgrd](https://repmgr.org/docs/4.0/repmgrd-bdr.html)

